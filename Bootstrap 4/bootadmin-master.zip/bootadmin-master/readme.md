BootAdmin is a free Bootstrap 4 admin/backend template.

![Imgur](https://i.imgur.com/6dEMVSY.png)

# Demo & Documentation

Visit https://bootadmin.net for demo and documentation.

# Issues & Support

Use the github issues tab for issues & support.