// Animating dropdowns is temporary disabled
// Please feel free to send a pull request :)

// $(function() {
// 	$('.nav-profile > li > a').on('click', function() {
// 		var $el = $(this).next();


// 		animate({
// 			name: 'flipInX',
// 			selector: $el
// 		});
// 	});
// })
