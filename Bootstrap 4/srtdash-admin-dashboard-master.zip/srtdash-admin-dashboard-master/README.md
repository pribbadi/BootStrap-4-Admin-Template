# SRTdash admin dashboard
Free admin dashboard template

# Overview
srtdash is a full-featured, multipurpose, premium bootstrap admin template built with Bootstrap 4 Framework, HTML5, CSS and JQuery.

It is a fully responsive bootstrap admin template/bootstrap admin dashboard template that comes with a huge collection of reusable UI components & plugins.

We believe we have covered everything you need to set up an All kind of website.If there is something that you would like to know then we are happy to help you out.

# Template Features:

- 3 Deferent Home Version
- Totall Pages 46+
- Based on Bootstrap 4
- HTML5, CSS3, jQuery
- Fully Responsive
- Easy to customize
- W3C Validated Code
- Fontawesome Icons
- Themify Icons
- Free Google Fonts.
- All files are well commented
- Minimal and Clean
- Documentation
- Clean UI Elements
- Free Updates
- Quick support
- Displays well in all modern browsers and devices

## Note:
Images are only for demo purpose and not included with the download bundle.
